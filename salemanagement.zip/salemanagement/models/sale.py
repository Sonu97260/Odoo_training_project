from odoo import api, fields, models,_
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta

import logging
_logger = logging.getLogger(__name__)

class saleorder(models.Model):
    _inherit = 'sale.order'
    _description = 'sales Order'
    _order = 'date_order desc'

    state=fields.Selection(selection_add=[
    ('quotation_approved', 'Apporved Quotation')],tracking=True)

    def action_quotation_approve(self):
        for rec in self:
            print("qutation approved.........")
            rec.state = 'quotation_approved'

    @api.model
    def cron_approve_quotation(self):
        three_days_ago = datetime.now() - timedelta(days=3)
        orders = self.search([
            ('state', '=', 'sale'),
            ('date_order', '<=', three_days_ago)
        ])
        for order in orders:
            print("Automatically approving quotation for order............................:", order.name)
            order.state = 'quotation_approved'
            
    def order_apporved(self):
        for order in self:
            print("Order approved - sending email...")
            order.state = 'quotation_approved'
            template = self.env.ref('salemanagement.order_apporved_send_email_iddd', raise_if_not_found=False)
            if template:
                template.send_mail(order.id, force_send=True) 

    def order_report(self):
        report=self.env.ref('salemanagement.sale_order_report_pdf').read()[0]
        print("report....................",report)
        return report
    
    def send_email_confirmed(self):
        for order in self:
            print("Order approved - sending email...........")
            order.state = 'quotation_approved'
            template = self.env.ref('salemanagement.send_email_template', raise_if_not_found=False)
            if template:
                template.send_mail(order.id, force_send=True)

    # def xls_report(self):
    #     self.ensure_one()
    #     return self.env.ref('salemanagement.sale_order_report_xls').report_action(self)
