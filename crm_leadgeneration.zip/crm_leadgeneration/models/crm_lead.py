from odoo import api, fields, models,_
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError

import logging
_logger = logging.getLogger(__name__)

class CrmLead(models.Model):
    _inherit = 'crm.lead'
    _description = 'crm lead'

    
    show_button=fields.Boolean(string="show ",compute="_compute_show_transfer_button")
    lead_num = fields.Char(string="Lead Number", readonly=True, copy=False)

    
    def _compute_show_transfer_button(self):
        print("\n _compute_show_transfer_button..........")
        enabled_button = self.env['ir.config_parameter'].sudo().get_param(
            'crm_leadgeneration.lead_num'
        ) == 'True'
        print("\n enabled_button ...........", enabled_button)
        for lead in self:
            if enabled_button:
                lead.show_button =  enabled_button
            else:
                lead.show_button = False



    @api.model
    def create(self, vals):
        config = self.env['ir.config_parameter'].sudo()

        lead_num = config.get_param('crm_leadgeneration.lead_num') == 'True'
        prefix = config.get_param('crm_leadgeneration.prefix', 'LEAD')
        start_num = int(config.get_param('crm_leadgeneration.start_num', 1))
        current_num = int(config.get_param('crm_leadgeneration.current_num', start_num))
        digit_length = int(config.get_param('crm_leadgeneration.digit_length', 1))

        if current_num < start_num:
            current_num = start_num
            config.set_param('crm_leadgeneration.current_num', start_num)

        if lead_num:
          
            if digit_length > 0:
                sequence = f"{prefix}{str(current_num).zfill(digit_length)}"
            else:
                sequence = f"{prefix}{current_num}"

            vals['lead_num'] = sequence
            vals['name'] = sequence
            config.set_param('crm_leadgeneration.current_num', current_num + 1)

        return super(CrmLead, self).create(vals)


    def action_open_transfer_wizard(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'crm.lead.transfer.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'active_ids': self.ids},
        }
    
    
    