from odoo import fields, models


class ResCompany(models.Model):
    _inherit = "res.company"

    lead_num = fields.Boolean(string="Enable Lead Numbering")
    prefix = fields.Char(string="Prefix", default='LEAD')
    start_num = fields.Integer(string="Start Number", default=1)
    current_num = fields.Integer(string="Current Number", readonly=True)
    digit_length = fields.Integer(string="Digit Length", default=1)


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    lead_num = fields.Boolean(string="Enable Lead Numbering", related="company_id.lead_num", readonly=False)
    prefix = fields.Char(string="Prefix", related="company_id.prefix", readonly=False)
    start_num = fields.Integer(string="Start Number", related="company_id.start_num", readonly=False)
    current_num = fields.Integer(string="Current Number", readonly=True, related="company_id.current_num")
    digit_length = fields.Integer(string="Digit Length", related="company_id.digit_length", readonly=False)


