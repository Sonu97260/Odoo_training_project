/** @odoo-module **/
import { patch } from "@web/core/utils/patch";
import { KanbanController } from "@web/views/kanban/kanban_controller";
import { useService } from "@web/core/utils/hooks";
import { onWillStart, onMounted, onWillUnmount } from "@odoo/owl";

patch(KanbanController.prototype, {
    setup() {
        super.setup(...arguments);
        this.orm = useService("orm");

        onMounted(() => {
            this.startTimerUpdates();
        });

        onWillUnmount(() => {
            if (this.timerInterval) {
                clearInterval(this.timerInterval);
            }
        });
    },

    startTimerUpdates() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
        }
        this.updateTimers();
        this.timerInterval = setInterval(() => this.updateTimers(), 1000);
    },

    async updateTimers() {
        const timerElements = document.querySelectorAll(".o_task_live_timer");

        for (const el of timerElements) {
            const taskId = el.dataset.taskId;
            if (!taskId) continue;

            try {
                const res = await this.orm.call(
                    "project.task",
                    "get_running_timer",
                    [[parseInt(taskId)]]
                );

                if (!res || !res.start_time) {
                    el.textContent = "⏱ 00:00:00";
                    continue;
                }

                const start = new Date(res.start_time + "Z");
                const now = new Date();
                const diff = Math.floor((now - start) / 1000);

                const h = String(Math.floor(diff / 3600)).padStart(2, "0");
                const m = String(Math.floor((diff % 3600) / 60)).padStart(2, "0");
                const s = String(diff % 60).padStart(2, "0");

                el.textContent = `${h}:${m}:${s}`;
            } catch (error) {
                console.error("Timer update error:", error);
            }
        }
    }
});
