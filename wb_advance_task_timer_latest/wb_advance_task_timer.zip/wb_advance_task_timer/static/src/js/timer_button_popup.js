/** @odoo-module **/

import { Component, useState, onWillDestroy } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

export class TaskTimerSystray extends Component {
    static template = "wb_advance_task_timer.TimerButton";

    setup() {
        this.action = useService("action");
        this.orm = useService("orm");

        this.state = useState({
            isRunning: false,
            duration: 0,
            startTime: null,
            taskName: '',
            timerId: null,
        });

        this.interval = null;
        onWillDestroy(() => clearInterval(this.interval));

        this._fetchRunningTimer();
    }

    async _fetchRunningTimer() {
        const result = await this.orm.call("project.task.timer", "action_get_running_timer", []);
        if (result.running) {
            this.state.isRunning = true;
            this.state.startTime = new Date(result.start_time + "Z");
            this.state.duration = result.duration;
            this.state.taskName = result.task_name;
            this.state.timerId = result.timer_id;
            this._startTimerInterval();
        } else {
            this.state.isRunning = false;
            this.state.duration = 0;
            clearInterval(this.interval);
        }
    }

    _startTimerInterval() {
        if (this.interval) clearInterval(this.interval);
        this.interval = setInterval(() => {
            this.state.duration++;
        }, 1000);
    }

    formatDuration(seconds) {
        const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
        const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
        const s = (seconds % 60).toString().padStart(2, '0');
        return `${h}:${m}:${s}`;
    }

    async onClick() {
        if (this.state.isRunning) {
            // If running, maybe open the task or pause? 
            // For now, let's keep the toggle logic but maybe just stop it strictly?
            // "When I click start task button it will Running timer visible... start task and cancel"
            // If already running, user might want to stop.
            // Let's assume clicking the main button while running behaves as a pause/stop toggle or opens details.
            // Requirement says "Start Task" button in popup starts it. 
            // Requirement doesn't explicitly say what clicking the running timer does, but usually it opens a menu or stops.
            // Existing logic was toggle. Let's keep "Stop" separate and make main click open wizard again? 
            // Or if running, maybe just do nothing or show info?
            // Let's implement Stop logic on the stop button and leave this potentially for viewing details.
            // But wait, the user said "when user click start button it will ... open popup". 
            // If running, the button text changes to "Pause" or Timer. 
            // Let's stick to the plan: "Implement Start button click handler to open the popup".
            // But if it is running, we probably shouldn't open the start popup again unless we want to start a NEW task (switching).
            // Let's assume clicking "Start" (when not running) opens popup.
            // If running, we might want to allow stopping.
            // Let's look at the XML.
        } else {
            // Open Wizard
            const action = {
                type: 'ir.actions.act_window',
                res_model: 'project.task.timer.wizard',
                view_mode: 'form',
                views: [[false, 'form']],
                target: 'new',
                // We need to know when wizard finishes to start timer. 
                // reliably doing this from JS side on wizard close is tricky without a mechanism.
                // One way: The wizard action returns a reload or a client action that triggers an update here.
                // Or we just poll every few seconds? 
                // Or we can pass a context that triggers a client action?
                // Simplest: Close wizard triggers a search.
                // We'll use the onClose callback of the action service if available, or just poll.
            };

            // Standard action call
            await this.action.doAction(action, {
                onClose: () => {
                    this._fetchRunningTimer();
                }
            });
        }
    }

    async onStop() {
        if (!this.state.timerId) return;

        const action = {
            name: 'End Task',
            type: 'ir.actions.act_window',
            res_model: 'project.task.end.wizard',
            view_mode: 'form',
            views: [[false, 'form']],
            target: 'new',
            context: {
                default_task_timer_id: this.state.timerId,
            }
        };

        await this.action.doAction(action, {
            onClose: () => {
                this._fetchRunningTimer();
            }
        });
    }
}

registry.category("systray").add(
    "wb_advance_task_timer.TaskTimerSystray",
    { Component: TaskTimerSystray },
    { sequence: 5 }
);
