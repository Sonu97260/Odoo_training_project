from odoo import models, fields, api, _
from odoo.exceptions import UserError
import logging
logger = logging.getLogger(__name__)    

class ProjectTask(models.Model):
    _inherit = 'project.task'
    _description = 'Project Task'   


    def action_start_timer(self):
        self.ensure_one()
        Timer = self.env['project.task.timer']

        # Check if any timer is already running for this user
        running_timer = Timer.search([
            ('user_id', '=', self.env.user.id),
            ('is_running', '=', True)
        ], limit=1)

        if running_timer:
            from odoo.exceptions import UserError
            raise UserError(f"You already have a running task: {running_timer.task_id.name}. Please stop it before starting a new one.")

        # Start new timer
        Timer.create({
            'user_id': self.env.user.id,
            'task_id': self.id,
            'project_id': self.project_id.id,
            'start_time': fields.Datetime.now(),
            'is_running': True,
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }
    # def action_start_timer(self):
    #     self.ensure_one()

    #     Timer = self.env['project.task.timer']

    #     # Stop other timers
    #     Timer.search([
    #         ('user_id', '=', self.env.user.id),
    #         ('is_running', '=', True)
    #     ]).write({'is_running': False})

    #     # Start new timer
    #     Timer.create({
    #         'user_id': self.env.user.id,
    #         'task_id': self.id,
    #         'project_id': self.project_id.id,
    #         'start_time': fields.Datetime.now(),
    #         'is_running': True,
    #     })

    #     # FORCE KANBAN RELOAD
    #     return {
    #         'type': 'ir.actions.client',
    #         'tag': 'reload',
    #     }
  

    def action_open_end_timer_wizard(self):
        print("open end timer wizard....................................")  
        self.ensure_one()

        timer = self.env['project.task.timer'].search([
            ('user_id', '=', self.env.user.id),
            ('is_running', '=', True),
            ('task_id', '=', self.id)
        ], limit=1)

        if not timer:
            logger.warning('No running timer found for task %s', self.id)   
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
            'params': {
                'title': 'No Running Timer',
                'message': 'No running timer found for this task.',
                'type': 'warning',
            }
        }

        return {
        'name': 'End Task',
        'type': 'ir.actions.act_window',
        'res_model': 'project.task.end.wizard',
        'view_mode': 'form',
        'views': [(False, 'form')],
        'target': 'new',
        'context': {
            'default_task_timer_id': timer.id,
        }
}

    def _search_is_timer_running(self, operator, value):
        timers = self.env['project.task.timer'].search([
            ('user_id', '=', self.env.user.id),
            ('is_running', '=', True)
        ])
        task_ids = timers.mapped('task_id').ids
        
        if (operator == '=' and value is True) or (operator == '!=' and value is False):
            return [('id', 'in', task_ids)]
        else:
            return [('id', 'not in', task_ids)]

    is_timer_running = fields.Boolean(
        compute="_compute_is_timer_running"
    )

    def _compute_is_timer_running(self):
        Timer = self.env['project.task.timer']
        for task in self:
            task.is_timer_running = bool(
                Timer.search([
                    ('task_id', '=', task.id),
                    ('user_id', '=', self.env.user.id),
                    ('is_running', '=', True)
                ], limit=1)
            )
                    
    
    # def _compute_is_timer_running(self):
    #     Timer = self.env['project.task.timer']
    #     for task in self:
    #         task.is_timer_running = bool(
    #             Timer.search([
    #                 ('task_id', '=', task.id),
    #                 ('user_id', '=', self.env.user.id),
    #                 ('is_running', '=', True)
    #             ], limit=1)
    #         )

    # is_timer_running = fields.Boolean(
    #         compute='_compute_is_timer_running',
    #         search='_search_is_timer_running',
    #         store=False,
    #         groups="base.group_user"
    # )
    def get_running_timer(self):
        self.ensure_one()
        timer = self.env['project.task.timer'].search([
            ('task_id', '=', self.id),
            ('user_id', '=', self.env.user.id),
            ('is_running', '=', True)
        ], limit=1)

        return {'start_time': timer.start_time if timer else False}

    # def get_running_timer(self):
    #     self.ensure_one()

    #     timer = self.env['project.task.timer'].search([
    #         ('task_id', '=', self.id),
    #         ('user_id', '=', self.env.user.id),
    #         ('is_running', '=', True)
    #     ], limit=1)

    #     return {
    #         'start_time': timer.start_time if timer else False
    #     }

class ProjectTaskTimer(models.Model):
    _name = 'project.task.timer'
    _description = 'Project Task Timer'

    user_id = fields.Many2one(
        'res.users',
        string='User',
        default=lambda self: self.env.user,
        required=True
    )
    project_id = fields.Many2one('project.project', string='Project')
    task_id= fields.Many2one('project.task', string='Task')
    # start_date = fields.Datetime(
    #     string='Start Date',
    #     default=fields.Datetime.now
    # )
    start_time = fields.Datetime()
    is_running = fields.Boolean(default=False)
    description = fields.Text(string="Task Description") 
    
    end_date = fields.Datetime(string='End Date')

    @api.model
    def action_toggle_timer(self):
        timer = self.search([
            ('user_id', '=', self.env.user.id),
            ('is_running', '=', True)
        ], limit=1)

        if timer:
            timer.write({
                'is_running': False,
            })
            return {'running': False}
        else:
            return {'running': True}

    @api.model
    def action_get_running_timer(self):
        timer = self.search([
            ('user_id', '=', self.env.user.id),
            ('is_running', '=', True)
        ], limit=1)
        if timer:
            duration = (fields.Datetime.now() - timer.start_time).total_seconds()
            return {
                'running': True,
                'duration': int(duration),
                'start_time': timer.start_time,
                'task_name': timer.task_id.name or 'Unknown Task',
                'timer_id': timer.id,
            }
        return {'running': False, 'duration': 0}