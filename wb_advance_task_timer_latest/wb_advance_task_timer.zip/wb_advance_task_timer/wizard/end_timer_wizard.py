from odoo import models, fields, api
from datetime import datetime

class ProjectTaskEndWizard(models.TransientModel):
    _name = 'project.task.end.wizard'
    _description = 'Project Task End Wizard'

    task_timer_id = fields.Many2one('project.task.timer', string='Timer', required=True)
    task_description = fields.Text(string='Enter Task Description')
    
    start_date = fields.Datetime(
        string='Start Date',
        related='task_timer_id.start_time',  # already correct
        readonly=True
    )
    end_date = fields.Datetime(string='End Date', default=fields.Datetime.now, readonly=True)
    duration = fields.Char(string='Duration (HH:MM)', compute='_compute_duration')

    @api.depends('start_date', 'end_date')
    def _compute_duration(self):
        for record in self:
            if record.start_date and record.end_date:
                diff = record.end_date - record.start_date
                total_seconds = int(diff.total_seconds())
                hours, remainder = divmod(total_seconds, 3600)
                minutes, _ = divmod(remainder, 60)
                record.duration = f"{hours:02}:{minutes:02}"
            else:
                record.duration = "00:00"


    def action_end_task(self):
        self.ensure_one()
        
        # Ensure we use the exact current time for accurate duration
        self.end_date = fields.Datetime.now()
        
        # Calculate unit_amount in hours
        duration_seconds = (self.end_date - self.start_date).total_seconds()
        unit_amount = duration_seconds / 3600.0

        # Create timesheet entry
        self.env['account.analytic.line'].create({
            'name': self.task_description or '/',
            'project_id': self.task_timer_id.project_id.id,
            'task_id': self.task_timer_id.task_id.id,
            'date': fields.Date.context_today(self),
            'unit_amount': unit_amount,
            'user_id': self.task_timer_id.user_id.id,
            'employee_id': self.env['hr.employee'].search([('user_id', '=', self.task_timer_id.user_id.id)], limit=1).id,
        })

        self.task_timer_id.write({
            'start_time': self.start_date,
            'end_date': self.end_date,
            'description': self.task_description,
            'is_running': False,
        })
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }
