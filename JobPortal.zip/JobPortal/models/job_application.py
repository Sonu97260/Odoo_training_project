# applicant_name, email, phone, cv_attachment (binary),
# job_id (Many2one to job.position)
# status (selection: draft, submitted, shortlisted, rejected, hired)

from odoo import models, fields,api# type: ignore
from odoo.http import request # pyright: ignore[reportMissingImports]
from odoo.exceptions import ValidationError # type: ignore
from datetime import date,timedelta
import logging


class JobApplication(models.Model):
    _name="job.application"
    _description="Job application"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name=fields.Char(string="Name")
    email=fields.Char(string="Email",offset=1)
    phone=fields.Char(string="Phone")
    cv_attachment=fields.Binary(string="CV attachment",attachment=True,help="upload the cv here")
    job_id=fields.Many2one('job.position',string="Jobs")


    status=fields.Selection([
        ('draft','draft'),
        ('submitted','submitted'),
        ('shortlisted','shortlisted'),
        ('rejected','rejected'),
        ('hired','hired')],string='Status',
        readonly=True, 
        default='draft',
        tracking=True,
    )
    
    email_domain=fields.Char(string="Email Domain")

    @api.onchange('email')
    def _onchange_email(self):
        if self.email and "@" in self.email:
            self.email_domain = self.email.split('@')[-1]
        else:
            self.email_domain = False


    def action_submitted(self):
        for record in self:
            record.status = 'submitted' 
          

    def action_shortlisted(self):
        for record in self:
            record.status = 'shortlisted' 

    def action_reject(self):
        for record in self:
            record.status = 'rejected' 

    def action_hire(self): 
        for record in self:
            record.status = 'hired'
        
        
    def send_email(self):
        job=self.search([('status','=','shortlisted')])
        for rec in job:
            if rec.email:
                template=self.env.ref('JobPortal.job_shortlisted_email_template')
                template.send_mail(rec.id)
               



            

  

