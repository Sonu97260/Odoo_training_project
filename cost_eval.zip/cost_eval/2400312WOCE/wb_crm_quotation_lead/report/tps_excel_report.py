import io
import os
import xlsxwriter
from odoo import http
from odoo.http import request

class TPSExcelReportController(http.Controller):

    @http.route('/wb_crm_quotation_lead/tps_excel_report/<model("sale.order"):order>', type='http', auth="user")
    def download_tps_excel_report(self, order, **kw):
        """Generates and downloads the TPS Excel report."""
        
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet('TPS Report')

        # Formats
        header_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'bold': True,
            'align': 'center',
            'valign': 'vcenter',
            'border': 0, 
            'bottom': 1, 
        })
        
        title_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 20,
            'bold': True,
            'align': 'center',
            'valign': 'vcenter',
            'underline': True
        })

        normal_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'valign': 'vcenter',
            'text_wrap': True
        })
        
        bold_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'bold': True,
            'valign': 'vcenter',
        })

        section_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'bold': True,
            'valign': 'vcenter',
            'bg_color': '#e9ecef',
            'text_wrap': True
        })
        
        red_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'valign': 'vcenter',
            'text_wrap': True,
            'font_color': 'red'
        })

        currency_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'valign': 'vcenter',
            'num_format': '#,##0.00'
        })
        
        red_currency_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'valign': 'vcenter',
            'font_color': 'red',
            'num_format': '#,##0.00'
        })
        
        section_currency_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'bold': True,
            'valign': 'vcenter',
            'bg_color': '#e9ecef',
            'num_format': '#,##0.00'
        })

        section_format_no_bg = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'bold': True,
            'valign': 'vcenter',
        })

        section_currency_format_no_bg = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'bold': True,
            'valign': 'vcenter',
            'num_format': '#,##0.00'
        })

        normal_no_wrap_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'valign': 'vcenter',
            'text_wrap': False
        })

        # Fixed Column Widths   
        sheet.set_column(0, 0, 8)  #    
        sheet.set_column(1, 1, 5)  # QTY
        sheet.set_column(2, 2, 20) # TYPE (Column C)
        sheet.set_column(3, 3, 65) # DESCRIPTION (Column D)
        sheet.set_column(4, 8, 12) # Prices
        sheet.set_column(9, 9, 15) # SUB-NSP / Customer Supply

        def write_cell(row, col, data, fmt=None):
            sheet.write(row, col, data, fmt)

        # Logo
        logo_path = os.path.join(os.path.dirname(__file__), '../static/src/img/logo.png')
        if os.path.exists(logo_path):
            sheet.insert_image('C1', logo_path, {'x_scale': 1.5, 'y_scale': 1.5})

        address_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'valign': 'vcenter',
            'align': 'center',
            'text_wrap': True
        })

        # Center text in the 8-row header space (Rows 0-7)
        # Title at Row 4 (Index 3), Address at Row 6 (Index 5) with gap at Row 5
        sheet.write('D4', 'TOTALPOWER SYSTEMS CORPORATION', title_format)
        sheet.write('D6', 'Lot 11, Block 3, Cebu Light Industrial Park, Lapu-Lapu City, Philippines', address_format)
        
        # Horizontal Line at Row 8 (Index 7)
        # border_format = workbook.add_format({'bottom': 1})
        # for col in range(10):
        #     sheet.write(7, col, '', border_format)

        row = 7
        # Freeze panes
        sheet.freeze_panes(row + 1, 0)
        row += 1
        
        # Date
        write_cell(row, 0, 'Date :', bold_format)
        sheet.write(row, 1, order.date_order.strftime('%B %d, %Y') if order.date_order else '', bold_format)
        row += 1
        
        # File
        write_cell(row, 0, 'File :', bold_format)
        sheet.write(row, 1, order.name.replace('File ', '') if order.name else '')
        row += 2

        # Client
        write_cell(row, 0, 'Client', normal_format)
        # write_cell(row, 1, ':', normal_format)
        sheet.write(row, 2, ': ' + order.partner_id.name or '', workbook.add_format({'font_name': 'Century Gothic', 'font_size': 14, 'bold': True}))
        row += 2

        # Project
        write_cell(row, 0, 'Project', normal_format)
        # write_cell(row, 1, ':', normal_format)
        sheet.write(row, 2, ': ' + (order.wb_project_id.name or ''), normal_no_wrap_format)
        row += 2

        # To
        write_cell(row, 0, 'To', normal_format)
        # write_cell(row, 1, ':', normal_format)
        sheet.write(row, 2, ': ' + (', '.join(order.wb_to.mapped('name')) or ''), normal_no_wrap_format)
        row += 2

        # Subject
        write_cell(row, 0, 'Subject', normal_format)
        # write_cell(row, 1, ':', normal_format)
        sheet.write(row, 2, ': ' + (order.wb_subject.name or ''), normal_no_wrap_format)
        row += 2

        # Intro
        sheet.merge_range(row, 0, row, 9, "In response to your inquiry, we are pleased to submit our proposal on the mentioned subject for", normal_format)
        row += 1
        sheet.merge_range(row, 0, row, 9, "your evaluation and approval.", normal_format)
        row += 2
        
        sheet.merge_range(row, 0, row, 9, "Customers are welcome to visit our fabrication facility.", bold_format)
        row += 2

        # --- TABLE HEADERS ---
        headers = ['ITEM', 'QTY', 'TYPE', 'DESCRIPTION', 'UNIT PRICE', 'SUB-NSP', 'SUB-NSP(PB)', 'MARGIN', 'UNIT PRICE', 'SUB-NSP']
        for col, text in enumerate(headers):
            write_cell(row, col, text, header_format)
        
        # Freeze panes
        # sheet.freeze_panes(row + 1, 0)
        
        row += 1

        # --- TABLE DATA ---
        for line in order.order_line:
            is_section = line.display_type == 'line_section'
            is_subsection = line.display_type == 'line_subsection'
            
            if is_section:
                write_cell(row, 0, line.wb_section_sequence, section_format)
                write_cell(row, 1, line.wb_section_qty, section_format)
                write_cell(row, 2, line.wb_section_name or '', section_format)
                write_cell(row, 3, line.name or '', section_format)
                write_cell(row, 4, '', section_format_no_bg)
                write_cell(row, 5, '', section_format_no_bg)
                
                # Section Total
                total_val = line.get_section_sub_nsp_pb_total()
                write_cell(row, 6, total_val, section_currency_format_no_bg)
                
                write_cell(row, 7, line.wb_sub_nsp_pb_margin_price, section_currency_format_no_bg)
                write_cell(row, 8, line.wb_section_price_unit, section_currency_format_no_bg)
                write_cell(row, 9, line.wb_total_sub_nsp_price, section_currency_format_no_bg)
                row += 1
                
            elif is_subsection:
                write_cell(row, 3, line.name or '', bold_format)
                row += 1
                
            else: # Regular Item
                # Determine style
                style = red_format if line.wb_is_show_to_client else normal_format
                curr_style = red_currency_format if line.wb_is_show_to_client else currency_format
                
                write_cell(row, 0, '', style) # Item col empty for products in PDF
                write_cell(row, 1, line.product_uom_qty, style)
                write_cell(row, 2, line.product_id.name or '', style)
                write_cell(row, 3, line.wb_product_description or '', style)
                
                if not line.wb_is_customer_supply:
                    write_cell(row, 4, line.price_unit, curr_style)
                    write_cell(row, 5, line.wb_sub_nsp_price, curr_style)
                else:
                    write_cell(row, 4, '', style)
                    write_cell(row, 5, '', style)

                write_cell(row, 6, '', style)
                write_cell(row, 7, '', style)
                write_cell(row, 8, '', style)
                
                if line.wb_is_show_to_client:
                    write_cell(row, 9, 'Customer Supply', normal_format)
                else:
                    write_cell(row, 9, '', style)
                    
                row += 1

        row += 2

        # --- TOTAL SECTION ---
        # Right aligned total
        bold_yellow_format = workbook.add_format({'bold': True, 'bg_color': 'yellow', 'align': 'right'})
        bold_yellow_num_format = workbook.add_format({'bold': True, 'bg_color': 'yellow', 'align': 'right', 'num_format': '#,##0.00'})

        if order.wb_discount:
            sheet.merge_range(row, 7, row, 8, 'Total Before Discount :', bold_yellow_format)
            sheet.write(row, 9, order.wb_before_discount_sub_total, bold_yellow_num_format)
            row += 1
            sheet.merge_range(row, 7, row, 8, 'Discount :', bold_yellow_format)
            sheet.write(row, 9, order.wb_discount, bold_yellow_num_format)
            row += 1
        sheet.merge_range(row, 7, row, 8, 'Total :', bold_yellow_format)
        sheet.write(row, 9, order.wb_final_amount, bold_yellow_num_format)
        row += 1
        sheet.write(row, 9, f"VAT - {order.wb_vat_id.vat_note or ''}", workbook.add_format({'font_size': 8, 'align': 'right', 'bg_color': 'yellow'}))
        row += 2

        # --- NOTE ---
        note_text = f"NOTE : {order.wb_note_id.note or ''}"
        sheet.write(row, 3, note_text, workbook.add_format({'bold': True, 'bg_color': 'yellow', 'align': 'left'}))
        row += 2

        # --- TERMS AND CONDITIONS ---
        # picking_ids = order.picking_ids.filtered(lambda x: x.state != 'cancel')
        # delivery_name = picking_ids[0].name if picking_ids else ''
        
        write_cell(row, 0, 'Terms and Conditions:', bold_format)
        row += 1
        
        write_cell(row, 0, 'Payment', normal_format)
        # write_cell(row, 1, ':', normal_format)
        sheet.write(row, 2, ': ' + (order.payment_term_id.name or ''), normal_no_wrap_format)
        row += 1
        
        write_cell(row, 0, 'Delivery', normal_format)
        # write_cell(row, 1, ':', normal_format)
        sheet.write(row, 2, ': ' + (order.wb_delivery_id.delivery_note or ''), normal_no_wrap_format)
        row += 1
        
        # validity = f"{order.wb_expiry_days_words or ''} ({order.wb_expiry_days or ''}) days from the date of offer"
        write_cell(row, 0, 'Validity', normal_format)
        sheet.write(row, 2, ': ' + (order.wb_validity_id.validity or ''), normal_no_wrap_format)
        row += 1
        
        write_cell(row, 0, 'Warranty', normal_format)
        # write_cell(row, 1, ':', normal_format)
        sheet.write(row, 2, ': ' + (order.wb_warranties_id.name or ''), normal_no_wrap_format)
        row += 2

        # --- CLOSING ---
        sheet.merge_range(row, 0, row, 9, "Thank you for the opportunity of quoting and we are looking forward to receiving your valued order.", normal_format)
        row += 2
        
        sheet.merge_range(row, 0, row, 3, "Respectfully yours,", normal_format)
        row += 1
        sheet.merge_range(row, 0, row, 3, "Total Power Box Solution, Inc.", bold_format)
        row += 3

        # --- SIGNATURES ---
        # Prepared by
        sheet.write(row, 1, "Prepared by:", workbook.add_format({'align': 'center'}))
        sheet.write(row, 7, "Approved by:", workbook.add_format({'align': 'center'}))
        row += 3
        
        # Cost Estimator Logic
        prepared_by_user = order.opportunity_id.user_id or order.user_id
        sheet.write(row, 1, prepared_by_user.name if prepared_by_user else '', workbook.add_format({'bold': True, 'align': 'center'}))
        sheet.write(row, 7, "HOMER GUTIERREZ", workbook.add_format({'bold': True, 'align': 'center'}))
        row += 1
        
        sheet.write(row, 1, prepared_by_user.cus_designation if prepared_by_user and prepared_by_user.cus_designation else '', workbook.add_format({'align': 'center'}))
        sheet.write(row, 7, "Sales Manager", workbook.add_format({'align': 'center'}))



        workbook.close()
        output.seek(0)
        
        file_name = f'TPS_Report_{order.name}.xlsx'
        
        return request.make_response(
            output.read(),
            headers=[
                ('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
                ('Content-Disposition', f'attachment; filename="{file_name}"')
            ]
        )
