def generate_internal_quotation_xlsx(self):
    self.ensure_one()

    import io
    import base64
    import xlsxwriter
    import os

    output = io.BytesIO()
    workbook = xlsxwriter.Workbook(output, {'in_memory': True})
    sheet = workbook.add_worksheet('CUSTOMER QUOTATION')

    # =====================================================
    # FORMATS
    # =====================================================
    title = workbook.add_format({
        'bold': True,
        'font_size': 16,
        'align': 'center',
        'valign': 'vcenter'
    })

    header = workbook.add_format({
        'font_name': 'Century Gothic',
        'bold': True,
        'font_size': 11
    })

    normal = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10
    })

    normal_center = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10,
        'align': 'center'
    })

    table_header = workbook.add_format({
        'font_name': 'Century Gothic',
        'bold': True,
        'align': 'center',
        'valign': 'middle'
    })

    cell = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10,
        'valign': 'top',
        'text_wrap': True,
    })

    gray_cell = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10,
        'bg_color': '#D9D9D9',
        'bold': True,
        'valign': 'top',
        'text_wrap': True,
    })

    total_format = workbook.add_format({
        'bold': True,
        'align': 'right',
        'bg_color': '#FFFF00'
    })

    label = workbook.add_format({
        'bold': True,
        'font_size': 10
    })

    value = workbook.add_format({
        'font_size': 10,
        'text_wrap': True
    })

    center_bold = workbook.add_format({
        'bold': True,
        'align': 'center'
    })

    center = workbook.add_format({
        'align': 'center'
    })

    company_name = workbook.add_format({
        'bold': True,
        'font_size': 16,
        'align': 'center',
        'underline': True
    })

    company_address = workbook.add_format({
        'font_size': 10,
        'align': 'center',
        'text_wrap': True
    })

    delivery_note_format = workbook.add_format({
        'bold': True,
        'align': 'center',
        'valign': 'vcenter',
        'text_wrap': True,
        'bg_color': '#FFFF00',
    })

    bold_format = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10,
        'bold': True,
        'valign': 'vcenter',
    })

    normal_no_wrap_format = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10,
        'valign': 'vcenter',
        'text_wrap': False,
    })

    # =====================================================
    # COLUMN WIDTH
    # =====================================================
    sheet.set_column(0, 0, 8)  # Item
    sheet.set_column(1, 1, 5)  # Qty
    sheet.set_column(2, 2, 20) # Type
    sheet.set_column(3, 3, 65) # Description
    sheet.set_column(4, 8, 15) # Prices
    sheet.set_column(9, 9, 15) # Total

    # =====================================================
    # HEADER (FIXED — NO OVERLAP)
    # =====================================================
    address_format = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10,
        'valign': 'vcenter',
        'align': 'center', # Align center for the address block in Col D
        'text_wrap': True
    })

    address_bold_format = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10,
        'valign': 'vcenter',
        'align': 'left',
        'text_wrap': True,
        'bold': True
    })
    
    title_format = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 20,
        'bold': True,
        'align': 'center',
        'valign': 'vcenter',
        'underline': True
    })

    # =====================================================
    # HEADER (FIXED — NO OVERLAP)
    # =====================================================
    row = 0

    # Logo
    logo_path = os.path.join(os.path.dirname(__file__), '../static/src/img/logo.png')
    if os.path.exists(logo_path):
        sheet.insert_image('C1', logo_path, {'x_scale': 1.5, 'y_scale': 1.5})

    # Company Details
    sheet.write('D4', 'TOTALPOWER SYSTEMS CORPORATION', title_format)
    sheet.write('D6', 'Lot 11, Block 3, Cebu Light Industrial Park, Lapu-Lapu City, Philippines', address_format)

    row = 7
    # Freeze panes
    sheet.freeze_panes(row + 1, 0)
    row += 1

    # =====================================================
    # META INFO
    # =====================================================
    def write_cell(row, col, data, fmt=None):
        sheet.write(row, col, data, fmt)

    # Date
    write_cell(row, 0, 'Date :', bold_format)
    sheet.write(row, 1, self.date_order.strftime('%B %d, %Y') if self.date_order else '', bold_format)
    row += 1
    
    # File
    write_cell(row, 0, 'File :', bold_format)
    sheet.write(row, 1, self.name.replace('File ', '') if self.name else '')
    row += 2

    # Client
    write_cell(row, 0, 'Client', normal)
    sheet.write(row, 2, ': ' + (self.partner_id.name or ''), workbook.add_format({'font_name': 'Century Gothic', 'font_size': 14, 'bold': True}))
    row += 2

    # Project
    write_cell(row, 0, 'Project', normal)
    sheet.write(row, 2, ': ' + (self.wb_project_id.name or ''), normal_no_wrap_format)
    row += 2

    # To
    write_cell(row, 0, 'To', normal)
    sheet.write(row, 2, ': ' + (self.partner_id.child_ids[:1].name if self.partner_id.child_ids else ''), normal_no_wrap_format)
    row += 2

    # Subject
    write_cell(row, 0, 'Subject', normal)
    sheet.write(row, 2, ': ' + (self.wb_subject.name or ''), normal_no_wrap_format)
    row += 2

    # Intro
    sheet.merge_range(row, 0, row, 9, "In response to your inquiry, we are pleased to submit our proposal on the mentioned subject for", normal)
    row += 1
    sheet.merge_range(row, 0, row, 9, "your evaluation and approval.", normal)
    row += 2
    
    sheet.merge_range(row, 0, row, 9, "Customers are welcome to visit our fabrication facility.", bold_format)
    row += 2

    # =====================================================
    # TABLE HEADER
    # =====================================================
    headers = ['ITEM', 'QTY', 'TYPE', 'DESCRIPTION', 'UNIT PRICE', 'SUB-NSP']
    for col, h in enumerate(headers):
        sheet.write(row, col, h, table_header)
    row += 1

    # =====================================================
    # TABLE BODY
    # =====================================================
    item_no = 1

    for line in self.order_line.filtered(lambda l: not l.wb_is_show_to_client):
        is_section = line.display_type == 'line_section'
        is_subsection = line.display_type == 'line_subsection'

        left_fmt = gray_cell if is_section else cell
        right_fmt = cell

        sheet.write(row, 0, item_no if is_section else '', left_fmt)
        sheet.write(row, 1, '' if is_section or is_subsection else line.product_uom_qty or '', left_fmt)

        sheet.write(
            row, 2,
            line.wb_section_name if (is_section or is_subsection)
            else (line.product_id.name or ''),
            left_fmt
        )

        description = line.name if (is_section or is_subsection) else (line.wb_product_description or '').replace('\r', '')
        sheet.write(row, 3, description, left_fmt)

        if is_section:
            sheet.write(row, 4, line.wb_section_price_unit, right_fmt)
        elif line.price_unit < 0:
            sheet.write(row, 4, line.price_unit, right_fmt)
        else:
            sheet.write(row, 4, '', right_fmt)

        if is_section:
            sheet.write(row, 5, line.wb_total_sub_nsp_price or '', right_fmt)
        elif line.wb_is_customer_supply:
            sheet.write(row, 5, 'Customer Supply', right_fmt)
        elif line.price_unit < 0:
            sheet.write(row, 5, line.wb_sub_nsp_price or '', right_fmt)
        else:
            sheet.write(row, 5, '', right_fmt)

        row += 1
        if is_section:
            item_no += 1

    # =====================================================
    # TOTAL
    # =====================================================
    row += 1
    if self.wb_discount:
        sheet.merge_range(
            row, 4, row, 5,
            f"Total Before Discount : {self.wb_before_discount_sub_total}",
            total_format
        )
        row += 1
        sheet.merge_range(
            row, 4, row, 5,
            f"Discount : {self.wb_discount}",
            total_format
        )
        row += 1
    sheet.merge_range(row, 4, row, 5, f"Total : {self.wb_final_amount}", total_format)
    row += 1
    sheet.merge_range(row, 4, row, 5, f"Vat: {self.wb_vat_id.vat_note if self.wb_vat_id else ''}", total_format)

    row += 3
    sheet.merge_range(
        row, 0, row, 5,
        f"NOTE : {self.wb_note_id.note}" if self.wb_note_id else "NOTE : DELIVERY AT SITE NOT INCLUDED IN THE OFFER",
        delivery_note_format
    )

    # =====================================================
    # FOOTER
    # =====================================================
    row += 4
    write_cell(row, 0, 'Terms and Conditions:', bold_format)
    row += 1

    write_cell(row, 0, 'Payment', normal)
    sheet.write(row, 2, ': ' + (self.payment_term_id.name or ''), normal_no_wrap_format)
    row += 1

    write_cell(row, 0, 'Delivery', normal)
    sheet.write(row, 2, ': ' + (self.wb_delivery_id.delivery_note or ''), normal_no_wrap_format)
    row += 1

    write_cell(row, 0, 'Validity', normal)
    sheet.write(row, 2, ': ' + (self.wb_validity_id.validity if self.wb_validity_id else ''), normal_no_wrap_format)
    row += 1

    write_cell(row, 0, 'Warranty', normal)
    sheet.write(row, 2, ': ' + (self.wb_warranties_id.name or ''), normal_no_wrap_format)

    row += 2
    sheet.merge_range(
        row, 0, row, 5,
        'Thank you for the opportunity of quoting and we are looking forward to receiving your valued order.',
        value
    )

    row += 2
    sheet.merge_range(row, 0, row, 2, 'Prepared by:', center)
    sheet.merge_range(row, 3, row, 5, 'Approved by:', center)

    row += 3
    # Cost Estimator Logic
    prepared_by_user = self.opportunity_id.user_id or self.user_id
    sheet.merge_range(row, 0, row, 2, prepared_by_user.name if prepared_by_user else '', center_bold)
    sheet.merge_range(row, 3, row, 5, 'HOMER GUTIERREZ', center_bold)
    row += 1

    sheet.merge_range(row, 0, row, 2, prepared_by_user.cus_designation if prepared_by_user and prepared_by_user.cus_designation else '', center)
    sheet.merge_range(row, 3, row, 5, 'Sales Manager', center)

    # =====================================================
    # SAVE
    # =====================================================
    workbook.close()
    output.seek(0)

    attachment = self.env['ir.attachment'].create({
        'name': f'{self.name}.xlsx',
        'type': 'binary',
        'datas': base64.b64encode(output.read()),
        'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'res_model': 'sale.order',
        'res_id': self.id,
    })

    return {
        'type': 'ir.actions.act_url',
        'url': f'/web/content/{attachment.id}?download=true',
        'target': 'self',
    }