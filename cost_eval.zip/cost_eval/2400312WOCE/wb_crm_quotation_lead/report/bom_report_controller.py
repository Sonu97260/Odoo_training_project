import io
import xlsxwriter
from odoo import http
from odoo.http import request


class BOMReportController(http.Controller):

    @http.route('/wb_crm_quotation_lead/bom_excel_report/<model("sale.order"):order>', type='http', auth="user")
    def download_bom_excel_report(self, order, **kw):
        """Generates and downloads the BOM Excel report."""
        
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet('BOM')

        # Formats
        header_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'bold': True,
            'align': 'center',
            'valign': 'vcenter',
            'border': 1,
            'bg_color': '#FFFFFF'
        })
        
        title_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 20,
            'bold': True,
            'align': 'center',
            'valign': 'vcenter',
        })

        cell_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'border': 1,
            'valign': 'vcenter',
            'text_wrap': True
        })
        
        cell_center_format = workbook.add_format({
            'font_name': 'Century Gothic',
            'font_size': 10,
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
        })

        # Title
        sheet.merge_range('A1:E2', 'BILL OF MATERIALS', title_format)

        # Headers
        headers = ['ITEM', 'QTY', 'TYPE', 'DESCRIPTION', 'REMARKS']
        for col_num, header in enumerate(headers):
            sheet.write(3, col_num, header, header_format)

        # Column Widths
        sheet.set_column('A:A', 10) # Item
        sheet.set_column('B:B', 10) # Qty
        sheet.set_column('C:C', 20) # Type
        sheet.set_column('D:D', 60) # Description
        sheet.set_column('E:E', 20) # Remarks

        # Data
        row = 4
        counter = 1
        
        # Filter lines: include hidden to client, not section/note
        lines = order.order_line.filtered(lambda l: l.display_type not in ('line_section', 'line_subsection'))
        
        # Aggregate data
        aggregated_data = {}
        for line in lines:
            # We group by product_id to aggregate quantities regardless of other fields
            key = line.product_id
            
            if key not in aggregated_data:
                aggregated_data[key] = {
                    'qty': 0.0,
                    'product_name': line.product_id.name,
                    'description': line.wb_product_description,
                }
            
            aggregated_data[key]['qty'] += line.product_uom_qty

        # Write aggregated data
        for key, data in aggregated_data.items():
            c_fmt = cell_format
            c_center_fmt = cell_center_format

            sheet.write(row, 0, counter, cell_center_format)
            sheet.write(row, 1, data['qty'], c_center_fmt)
            sheet.write(row, 2, data['product_name'] or '', c_fmt)
            sheet.write(row, 3, data['description'] or '', c_fmt)
            sheet.write(row, 4, '', c_fmt) # Remarks is empty

            row += 1
            counter += 1

        workbook.close()
        output.seek(0)
        
        file_name = f'BOM_{order.name}.xlsx'
        
        return request.make_response(
            output.read(),
            headers=[
                ('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
                ('Content-Disposition', f'attachment; filename="{file_name}"')
            ]
        )
