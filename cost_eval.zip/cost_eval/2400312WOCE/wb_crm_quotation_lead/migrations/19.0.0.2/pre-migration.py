def migrate(cr, version):
    cr.execute("ALTER TABLE sale_order DROP COLUMN IF EXISTS wb_subject")
