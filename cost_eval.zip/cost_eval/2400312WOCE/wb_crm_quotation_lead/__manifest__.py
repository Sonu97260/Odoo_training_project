# -- coding: utf-8 --
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Wan Buffer Services (<https://wanbuffer.com/>).
#
#    For Module Support : info@wanbuffer.com  or Call : +91 9638442270
#
##############################################################################

{
    'name': "CRM Quoation Lead",
    'version': '19.0.0.2',
    'category': 'Sales',
    "license": "OPL-1",
    'author': 'Wan Buffer Services',
    'website': 'https://wanbuffer.com',
    'summary': "Genarate the quoation from crm leads",
    'description': """
Allows to generate quotation from crm leads.

Contact Us:

* Support: support@wanbuffer.com
* Sales: sales@wanbuffer.com
* Phone: +91 9638442270
    """,
    'depends': ['base', 'account', 'sale_management', 'sale_crm', 'stock', 'spreadsheet_dashboard', 'crm_iap_enrich'],
    'data': [
        'data/ir_sequence.xml',
        'security/module_access_groups.xml',
        'security/ir.model.access.csv',
        'wizard/sale_discount.xml',
        'wizard/duplicate_lead_wizard_view.xml',
        'wizard/internal_quotation.xml',
        'wizard/customer_quotation.xml',
        'report/sale_order_reports.xml',
        'report/tps_report.xml',
        'report/tps_cs_report.xml',
        'report/ir_action_report.xml',
        'report/internal_report.xml',
        'views/crm_lead_views.xml',
        'views/crm_iap_enrich_override.xml',
        'views/crm_stage_views.xml',
        'views/sale_order_views.xml',
        'views/product_template_views.xml',
        'views/product_search_view.xml',
        'views/portal_sale_templates.xml',
        'views/res_partner_views.xml',
        'views/res_users_views.xml',
        'views/wb_project_views.xml',
        'views/wb_warranties_views.xml',
        'views/wb_subject_views.xml',
        'views/wb_validity_views.xml',
        'views/crm_menus.xml',
        'views/vat_notes_views.xml',
        'views/notes_views.xml',
        'views/delivery_notes_views.xml',
        'views/log_in_view.xml',
        'views/hide_print_sale_views.xml',

    ],
    'assets': {
        'web.assets_backend': [
            'wb_crm_quotation_lead/static/src/css/custom.css',
            'wb_crm_quotation_lead/static/src/components/**/*.js',
            'wb_crm_quotation_lead/static/src/js/catalog_extension.js',
            'wb_crm_quotation_lead/static/src/js/form_controller_patch.js',
            'wb_crm_quotation_lead/static/src/js/list_controller_patch.js',
        ],
    },
    'application': False,
}
