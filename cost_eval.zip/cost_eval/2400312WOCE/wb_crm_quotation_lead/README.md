# wb_crm_quotation_lead

## Overview

The **wb_crm_quotation_lead** module extends the Odoo CRM functionality to improve the management of quotations directly from leads and opportunities.
It provides a seamless way for sales teams to create, track, and manage quotations without leaving the CRM interface.

---

## Key Features

- Create quotations directly from leads or opportunities.
- Automatically link quotations to corresponding CRM records.
- View related quotations within the lead/opportunity form.
- Enhanced reporting and tracking for lead-to-sale conversions.
- Configurable access rights based on user roles.

---


## Installation

1. Copy the module folder **`wb_crm_quotation_lead`** into your Odoo custom addons directory:
   ```bash
   /2400312WOCE/wb_crm_quotation_lead

## Contributing

Feel free to fork the repository and submit pull requests for any improvements or bug fixes.

## License

This module is licensed under the terms of the Odoo Proprietary License.
