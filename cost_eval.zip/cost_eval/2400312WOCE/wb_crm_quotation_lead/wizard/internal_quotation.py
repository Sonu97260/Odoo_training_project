from odoo import models, fields


class InternalQuotationWizard(models.TransientModel):
    _name = 'internal.quotation.wizard'
    _description = 'Internal Quotation Wizard'

    def action_print_total_powerbox_pdf(self):
        active_id = self.env.context.get('active_id')
        return self.env.ref('wb_crm_quotation_lead.action_report_tps_cs_custom').report_action(active_id)

    def action_print_total_powerbox_excel(self):
        active_id = self.env.context.get('active_id')
        return {
            'type': 'ir.actions.act_url',
            'url': f'/wb_crm_quotation_lead/tps_int_excel_report/{active_id}',
            'target': 'self',
        }

    def action_print_total_power_system_pdf(self):
        active_id = self.env.context.get('active_id')
        return self.env.ref('wb_crm_quotation_lead.action_report_tps_custom').report_action(active_id)

    def action_print_total_power_system_excel(self):
        active_id = self.env.context.get('active_id')
        return {
            'type': 'ir.actions.act_url',
            'url': f'/wb_crm_quotation_lead/tps_excel_report/{active_id}',
            'target': 'self',
        }