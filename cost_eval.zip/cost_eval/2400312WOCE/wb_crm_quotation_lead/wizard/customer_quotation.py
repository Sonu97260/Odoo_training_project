from odoo import models, fields
from odoo.addons.wb_crm_quotation_lead.report.tp_cs_excel import generate_customer_quotation_xlsx
from odoo.addons.wb_crm_quotation_lead.report.tp_int_excel import generate_internal_quotation_xlsx


class CustomerQuotationWizard(models.TransientModel):
    _name = 'customer.quotation.wizard'
    _description = 'Customer Quotation Wizard'

    def action_print_total_powerbox_pdf(self):
        active_id = self.env.context.get('active_id')
        return self.env.ref('wb_crm_quotation_lead.action_report_saleorder_custom').report_action(active_id)

    def action_print_total_powerbox_excel(self):
        active_id = self.env.context.get('active_id')
        order = self.env['sale.order'].browse(active_id)
        return generate_customer_quotation_xlsx(order)

    def action_print_total_power_system_pdf(self):
        active_id = self.env.context.get('active_id')
        return self.env.ref('wb_crm_quotation_lead.action_report_saleorder_totalpower_internal').report_action(
            active_id)

    def action_print_total_power_system_excel(self):
        active_id = self.env.context.get('active_id')
        order = self.env['sale.order'].browse(active_id)
        return generate_internal_quotation_xlsx(order)