from odoo import fields, models, api

class SaleOrderDiscount(models.TransientModel):
    _inherit = 'sale.order.discount'

    wb_discount_type = fields.Selection(
        selection=[
            ('so_discount', "Global Discount"),
            ('amount', "Fixed Amount"),
        ],
        default='so_discount',
        required=True,
    )
    discount_type = fields.Selection(
        selection=[
            ('sol_discount', "On All Order Lines"),
            ('so_discount', "Global Discount"),
            ('amount', "Fixed Amount"),
        ],
        default='so_discount',
    )

    @api.onchange('wb_discount_type')
    def _onchange_wb_discount_type(self):
        for record in self:
            record.discount_type = record.wb_discount_type

    def action_apply_discount(self):
        self.ensure_one()
        # Override Global Discount calc to use Gross Total (Before Discount)
        if self.discount_type == 'so_discount':
            # Calculate amount yourself
            base_amount = self.sale_order_id.wb_before_discount_sub_total
            # User confirmed multiplying by 100 fixes the value (implies percentage is 0.1 for 10%)
            discount_amount = base_amount * self.discount_percentage
            # Switch to fixed amount mode to force Odoo to use our calculated amount
            self.discount_type = 'amount'
            self.discount_amount = discount_amount
        return super().action_apply_discount()