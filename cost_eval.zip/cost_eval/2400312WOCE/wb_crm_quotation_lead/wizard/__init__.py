from . import sale_order_discount
from . import duplicate_lead_wizard
from . import internal_quotation
from . import customer_quotation