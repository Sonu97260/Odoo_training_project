from odoo import models, fields

class DuplicateLeadWizard(models.TransientModel):
    _name = 'crm.lead.duplicate.wizard'
    _description = 'Duplicate Lead'

    lead_id = fields.Many2one('crm.lead', string='Lead', readonly=True)
    quotation_ids = fields.Many2many('sale.order', string='Quotations', domain="[('opportunity_id', '=', lead_id)]")
    
    state = fields.Selection([
        ('step1', 'Step 1'),
        ('step2', 'Step 2')
    ], default='step1')

    action_type = fields.Selection([
        ('edit', 'Yes (allow edit)'),
        ('keep', 'Cancel (keep existing values)')
        
    ], string="Do you want to change Client or Project name?",
    default='keep',
    required=True)  
    
    partner_id = fields.Many2one('res.partner', string='Client')
    wb_project_id = fields.Many2one('wb.project', string='Project')

    def action_duplicate(self):
        self.ensure_one()
        self.state = 'step2'
        return {
            'name': 'Duplicate Lead',
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
            'context': self.env.context,
        }

    def action_final_duplicate(self):
        self.ensure_one()
        
        vals = {
            'name': self.lead_id.name + ' (Copy)',
            'wb_ro_counter': 0,
        }
        
        if self.action_type == 'edit':
            vals['wb_is_allow_edit'] = True
            if self.partner_id:
                vals['partner_id'] = self.partner_id.id
            if self.wb_project_id:
                vals['wb_project_id'] = self.wb_project_id.id
        else:
            vals['wb_is_allow_edit'] = False
        
        new_lead = self.lead_id.copy(vals)

        for quotation in self.quotation_ids.sorted(key=lambda r: r.id):
            quotation_vals = {
                'opportunity_id': new_lead.id,
                'state': 'draft',
                'wb_is_allow_edit': True if self.action_type == 'edit' else False
            }
            if self.action_type == 'edit':
                if self.partner_id:
                    quotation_vals['partner_id'] = self.partner_id.id
                if self.wb_project_id:
                    quotation_vals['wb_project_id'] = self.wb_project_id.id
            
            quotation.copy(quotation_vals)

        return {
            'type': 'ir.actions.act_window',
            'res_model': 'crm.lead',
            'view_mode': 'form',
            'res_id': new_lead.id,
        }