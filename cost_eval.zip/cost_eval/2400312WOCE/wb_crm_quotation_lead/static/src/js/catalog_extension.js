/** @odoo-module */
import { ProductCatalogKanbanController } from "@product/product_catalog/kanban_controller";
import { patch } from "@web/core/utils/patch";
import { onMounted, onPatched } from "@odoo/owl";

patch(ProductCatalogKanbanController.prototype, {
    setup() {
        if (super.setup) {
            super.setup();
        }
        onMounted(() => this._updateSectionNames());
        if (typeof onPatched === 'function') {
            onPatched(() => this._updateSectionNames());
        }
    },
    _updateSectionNames() {
        const updateDisplay = () => {
            const searchPanel = document.querySelector('.o_search_panel');
            if (!searchPanel) {
                setTimeout(updateDisplay, 500);
                return;
            }
            
            const sections = searchPanel.querySelectorAll('.o_section_name');
            sections.forEach(sectionEl => {
                sectionEl.style.visibility = 'visible';
                sectionEl.style.opacity = '1';
                sectionEl.style.display = '';
            });
        };
        
        updateDisplay();
    }
});