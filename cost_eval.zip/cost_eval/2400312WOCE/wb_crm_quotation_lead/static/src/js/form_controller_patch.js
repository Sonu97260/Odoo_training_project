/** @odoo-module */

import { FormController } from "@web/views/form/form_controller";
import { patch } from "@web/core/utils/patch";
import { _t } from "@web/core/l10n/translation";

patch(FormController.prototype, {
    getStaticActionMenuItems() {
        const items = super.getStaticActionMenuItems();
        if ((this.props.resModel === "sale.order" || this.props.resModel === "crm.lead") && items.delete) {
            items.delete.description = _t("Hard Delete");
        }
        return items;
    },
});
