/* @odoo-module */

import { patch } from "@web/core/utils/patch";
import { SectionAndNoteListRenderer } from "@account/components/section_and_note_fields_backend/section_and_note_fields_backend";

patch(SectionAndNoteListRenderer.prototype, {
    getColumns(record) {
        let activeColumn = this.getActiveColumns();
        let section_columns = null;
        if (['line_section'].includes(record.data?.display_type) && record?._config?.resModel == 'sale.order.line') {
            let columns = this.allColumns
                .filter(col => ["name", "sequence", "wb_section_name", "wb_section_sequence", "wb_section_qty", "wb_sub_nsp_price", "wb_total_sub_nsp_price", "wb_sub_nsp_pb_margin_price", "wb_section_price_unit"].includes(col.name))
                .map(col => {
                    if (col.name === "name") {
                        return { ...col, colspan: activeColumn.length - 8 };
                    }
                    if (col.name === "wb_section_sequence") {
                        return { ...col, readonly: false };
                    }
                    // Make calculated fields read-only for section lines
                    if (["wb_sub_nsp_pb_margin_price", "wb_section_price_unit"].includes(col.name)) {
                        return { ...col, readonly: true };
                    }
                    return { ...col };
                });
            section_columns = columns;
        } else if (['line_subsection'].includes(record.data?.display_type) && record?._config?.resModel == 'sale.order.line') {
            let columns = this.allColumns
                .filter(col => ["name", "sequence", "wb_section_name"].includes(col.name))
                .map(col => {
                    if (col.name === "name") {
                        return { ...col, colspan: activeColumn.length - 2 };
                    }
                    // Make calculated fields read-only for section lines
                    if (['sequence', 'wb_section_name'].includes(col.name)) {
                        return { ...col, readonly: true };
                    }
                    return { ...col };
                });
            section_columns = columns;
        }
        else {
            return super.getColumns(record)
        }
        return section_columns;
    },

    getFormattedValue(column, record) {
        let res = super.getFormattedValue(column, record);
        if (record._config.resModel === 'sale.order.line') {
            if (column.name === 'wb_sub_nsp_price') {
                const customer_margin = record.data['wb_customer_margin'];
                const hasValidId = record.resId && typeof record.resId === 'number';
                if (customer_margin) {
                    const margins = customer_margin.split("/").map(Number);
                    let sub_nsp_price = parseFloat(res.replace(/,/g, ""));
                    if (sub_nsp_price && margins.length > 0) {
                        let calculated_price = sub_nsp_price;
                        margins.forEach((m) => {
                            if (m !== 0 && !isNaN(m)) {
                                calculated_price = calculated_price / m;
                            }
                        });
                        if (record.data['wb_sub_nsp_pb_margin_price'] !== calculated_price) {
                            record.data['wb_sub_nsp_pb_margin_price'] = calculated_price;
                            if (hasValidId && record.resId) {
                                setTimeout(() => this.orm.write("sale.order.line", [record.resId], { wb_sub_nsp_pb_margin_price: calculated_price }), 0);
                            }
                        }
                        const unit_price = Math.ceil(calculated_price / 10) * 10;
                        if (record.data['wb_section_price_unit'] !== unit_price) {
                            record.data['wb_section_price_unit'] = unit_price;
                            if (hasValidId && record.resId) {
                                setTimeout(() => this.orm.write("sale.order.line", [record.resId], { wb_section_price_unit: unit_price }), 0);
                            }
                        }
                    } else {
                        if (record.data['wb_sub_nsp_pb_margin_price'] !== 0.0) record.data['wb_sub_nsp_pb_margin_price'] = 0.0;
                        if (record.data['wb_section_price_unit'] !== 0.0) record.data['wb_section_price_unit'] = 0.0;
                        if (record.data['wb_total_sub_nsp_price'] !== 0.0) record.data['wb_total_sub_nsp_price'] = 0.0;
                        if (hasValidId && record.resId) {
                            setTimeout(() => this.orm.write("sale.order.line", [record.resId], { wb_sub_nsp_pb_margin_price: 0.0, wb_section_price_unit: 0.0, wb_total_sub_nsp_price: 0.0 }), 0);
                        }
                    }
                } else {
                    if (record.data['wb_sub_nsp_pb_margin_price'] !== 0.0) record.data['wb_sub_nsp_pb_margin_price'] = 0.0;
                    if (record.data['wb_section_price_unit'] !== 0.0) record.data['wb_section_price_unit'] = 0.0;
                    if (record.data['wb_total_sub_nsp_price'] !== 0.0) record.data['wb_total_sub_nsp_price'] = 0.0;
                    if (hasValidId && record.resId) { setTimeout(() => this.orm.write("sale.order.line", [record.resId], { wb_total_sub_nsp_price: 0.0 }), 0); }
                }
            }
            if (column.name === 'wb_section_price_unit' || column.name === 'wb_section_qty') {
                const hasValidId = record.resId && typeof record.resId === 'number';
                const total_price = (record.data['wb_section_price_unit'] || 0.0) * (record.data['wb_section_qty'] || 0.0);
                if (record.data['wb_total_sub_nsp_price'] !== total_price) {
                    record.data['wb_total_sub_nsp_price'] = total_price;
                    if (hasValidId && record.resId) { setTimeout(() => this.orm.write("sale.order.line", [record.resId], { wb_total_sub_nsp_price: total_price }), 0); }
                }
            }
            // /['line_section'].includes(record.data?.display_type) && 
            // if (record.data['wb_total_sub_nsp_price'] !== 0.0 && column.name === 'wb_total_sub_nsp_price') {
            //     this.orm.call(record.resModel, 'get_section_total_sub_nsp_price', [record.data['wb_total_sub_nsp_price'], record.data['wb_section_sequence'], record.data.order_id.id], {});
            // }
        }
        return res;
    },

    // Prefer focusing the custom section field when creating a new section on sale.order.line
    focusToName(editRec) {
        console.debug('wb_crm: focusToName called', {editRec, record: this.record && {resModel: this.record._config?.resModel}});
        if (editRec && editRec.isNew && this.isSectionOrNote(editRec)) {
            try {
                // Use the edited record's config to detect the model reliably
                const resModel = editRec?._config?.resModel || this.record?._config?.resModel;
                console.debug('wb_crm: detected resModel for focus', resModel);
                if (resModel === 'sale.order.line') {
                    const customCol = this.columns.find((c) => c.name === 'wb_section_name');
                    console.debug('wb_crm: customCol found?', !!customCol, customCol);
                    if (customCol) {
                        console.debug('wb_crm: focusing customCol', customCol);
                        this.focusCell(customCol, null);
                        return;
                    }
                }
            } catch (e) {
                // ignore and fallback to default behavior
                console.warn('focusToName patch error', e);
            }
            const col = this.columns.find((c) => c.name === this.titleField);
            console.debug('wb_crm: focusing titleField col', col);
            this.focusCell(col, null);
        }
    },

});
