from odoo import models, fields

class WbDeliveryNotes(models.Model):
    _name = "wb.delivery.notes"
    _description = "Delivery Notes"
    _rec_name = 'delivery_note'

    delivery_note = fields.Char(string="Delivery Note", required=True)
