from odoo import models, fields

class WbVatNotes(models.Model):
    _name = "wb.vat.notes"
    _description = "VAT Notes"
    _rec_name = 'vat_note'

    vat_note = fields.Char(string="VAT Note", required=True)
