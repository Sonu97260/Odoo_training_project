from odoo import fields, models


class CrmStage(models.Model):
    _inherit = 'crm.stage'
    _description = "Crm Stages"

    wb_is_hide_quotation_button = fields.Boolean('Hide Quotation Button?')
