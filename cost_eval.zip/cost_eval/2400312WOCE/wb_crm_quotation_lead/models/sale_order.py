from odoo import api, fields, models, _
from odoo.exceptions import AccessError
from num2words import num2words


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    wb_subject = fields.Many2one('wb.subject', string='Subject')
    wb_to = fields.Many2many('res.partner',string='To',domain="[('parent_id','=', partner_id), ('type','=','contact')]")
    stage_id = fields.Many2one('crm.stage', related='opportunity_id.stage_id', string='Stage')
    wb_project_id = fields.Many2one('wb.project', string='Project')
    wb_vat_id = fields.Many2one('wb.vat.notes', string='VAT Notes', required=True)
    wb_note_id = fields.Many2one('wb.notes', string='Notes')
    wb_delivery_id = fields.Many2one('wb.delivery.notes', string='Delivery Notes')
    wb_validity_id = fields.Many2one('wb.validity', string='Validity Notes')
    wb_warranties_id = fields.Many2one('wb.warranties', string='Warranty Notes')
    wb_ro_sequence = fields.Char(string='RO Sequence')
    wb_lead_number = fields.Char(string='Lead Number', related='opportunity_id.wb_lead_number', readonly=True)
    wb_section_total_dict = fields.Json(default=lambda self: {})
    wb_expiry_days = fields.Integer(string="Valid Days", compute="wb__compute_expiry_days")
    wb_expiry_days_words = fields.Char(string="Valid Days (Words)", compute="_compute_expiry_words")
    wb_before_discount_sub_total = fields.Float(string="Total Before Discount", digits='Product Price', compute="_compute_wb_totals")
    wb_discount = fields.Float(string="Discount", digits='Product Price', compute="_compute_wb_totals")
    wb_final_amount = fields.Float(string="Total", digits='Product Price', compute="_compute_wb_totals")
    wb_sub_nsp_untaxed_amount = fields.Float(string="NSP Untaxed Amount", digits='Product Price', compute="_compute_wb_sub_nsp_untaxed_amount")
    active = fields.Boolean(default=True)
    user_has_discount_permission = fields.Boolean(
        string="User Can See Discount",
        compute="_compute_user_discount_access",
        store=False
    )
    wb_is_allow_edit = fields.Boolean(string="Allow Edit", default=True)
    wb_can_edit_restricted_fields = fields.Boolean(compute='_compute_wb_can_edit_restricted_fields')

    def _compute_wb_can_edit_restricted_fields(self):
        user = self.env.user
        allow = (
            user.has_group('wb_crm_quotation_lead.group_system_administrator') or
            user.has_group('wb_crm_quotation_lead.group_system_admin') or
            user.has_group('wb_crm_quotation_lead.group_supervisor') or
            user.has_group('wb_crm_quotation_lead.group_cost_estimator')
        )
        for rec in self:
            rec.wb_can_edit_restricted_fields = allow

    @api.depends('order_line.wb_sub_nsp_price', 'order_line.display_type','order_line.wb_total_sub_nsp_price')
    def _compute_wb_totals(self):
        for order in self:
            # Filter for real product lines (not sections/notes)
            lines = order.order_line.filtered(lambda x: not x.display_type)
            # Sum positive lines for Total Before Discount
            before_discount = sum(l.wb_total_sub_nsp_price for l in lines if l.wb_total_sub_nsp_price > 0)
            order.wb_before_discount_sub_total = before_discount
            # Sum negative lines for Discount (absolute value)
            discount = sum(abs(l.price_unit) for l in lines if l.price_unit < 0)
            order.wb_discount = discount
            # Final Total = Before Discount - Discount
            order.wb_final_amount = before_discount - discount

    @api.depends()
    def _compute_user_discount_access(self):
        for order in self:
            order.user_has_discount_permission = bool(
                self.env.user.allow_discount
            )

    def _compute_wb_sub_nsp_untaxed_amount(self):
        for order in self:
            order.wb_sub_nsp_untaxed_amount = sum(order.order_line.filtered(lambda x: x.display_type == 'line_section').mapped('wb_total_sub_nsp_price'))

    def _compute_expiry_words(self):
        for rec in self:
            if rec.wb_expiry_days:
                rec.wb_expiry_days_words = num2words(rec.wb_expiry_days, to='cardinal').title()
            else:
                rec.wb_expiry_days_words = ""

    def wb__compute_expiry_days(self):
        for rec in self:
            if rec.date_order and rec.validity_date:
                date1 = fields.Date.from_string(rec.date_order)
                date2 = fields.Date.from_string(rec.validity_date)
                rec.wb_expiry_days = (date2 - date1).days
            else:
                rec.wb_expiry_days = 0

    @api.model
    def _force_unbind_all_reports(self):
        reports = self.env['ir.actions.report'].search([
            ('model', '=', 'sale.order'),
            ('binding_model_id', '!=', False)
        ])
        for report in reports:
            report.write({'binding_model_id': False})
        return True

    # ---------------------------
    # FINAL CREATE METHOD (from Version 2)
    # ---------------------------
    @api.model_create_multi
    def create(self, vals_list):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not allowed to create quotations."))
        orders = super().create(vals_list)
        for order in orders:
            if order.opportunity_id:
                opportunity = order.opportunity_id

                # Generate RO sequence (V2 style)
                ro_seq = str(opportunity.wb_ro_counter or 0)
                order.wb_ro_sequence = f"R{ro_seq}"
                opportunity.wb_ro_counter += 1

                # Build name
                lead_number = opportunity.wb_lead_number or ''
                current_date = fields.Datetime.now()
                year_str = current_date.strftime('%y')
                month_str = current_date.strftime('%m')

                base_name = f"File  CE{year_str}{month_str}-{lead_number}{order.wb_ro_sequence}"
                            
                # Add user abbreviation
                user = self.env.user
                if user.wb_abbreviation_name:
                    base_name += f"-{user.wb_abbreviation_name.upper()}"

                order.name = base_name

        return orders

    def write(self, vals):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not allowed to edit quotations."))
        res = super().write(vals)

        for order in self:
            if order.name:
                parts = order.name.split("-")

                # Remove old abbreviation
                if len(parts) > 1:
                    base_name = "-".join(parts[:-1])
                else:
                    base_name = order.name

                # Add current logged-in user's abbreviation
                user = self.env.user
                if user.wb_abbreviation_name:
                    new_name = f"{base_name}-{user.wb_abbreviation_name.upper()}"
                else:
                    new_name = base_name

                # Write only if changed
                if order.name != new_name:
                    super(type(order), order).write({"name": new_name})

        return res

    def copy(self, default=None):
        self.ensure_one()
        default = dict(default or {})

        # Extract everything before the last "-" (remove old abbreviation)
        old_name = self.name or ""
        parts = old_name.split("-")

        if len(parts) > 1:
            # Remove last part (old abbreviation)
            base_name = "-".join(parts[:-1])
        else:
            base_name = old_name

        # Add new abbreviation based on current user
        user = self.env.user
        if user.wb_abbreviation_name:
            new_name = f"{base_name}-{user.wb_abbreviation_name.upper()}"
        else:
            new_name = base_name

        default["name"] = new_name

        return super().copy(default)

    def unlink(self):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not access to delete quotations."))
        return super().unlink()


    def _compute_tax_totals(self):
        AccountTax = self.env['account.tax']
        for order in self:
            order_lines = order.order_line.filtered(lambda x: not x.display_type)

            base_lines = [line._prepare_base_line_for_taxes_computation() for line in order_lines]
            base_lines += order._add_base_lines_for_early_payment_discount()

            AccountTax._add_tax_details_in_base_lines(base_lines, order.company_id)
            AccountTax._round_base_lines_tax_details(base_lines, order.company_id)
            tax_totals = AccountTax._get_tax_totals_summary(
                base_lines=base_lines,
                currency=order.currency_id or order.company_id.currency_id,
                company=order.company_id,
            )
            total_price = order.wb_sub_nsp_untaxed_amount

            for untaxed_total in tax_totals['subtotals']:
                untaxed_total['base_amount_currency'] = total_price
                untaxed_total['base_amount'] = total_price
                for tax_group in untaxed_total['tax_groups']:
                    tax_group['base_amount_currency'] = total_price
                    tax_group['base_amount'] = total_price
                    tax_group['display_base_amount_currency'] = total_price
                    tax_group['display_base_amount'] = total_price

            tax_totals['base_amount_currency'] = total_price
            tax_totals['base_amount'] = total_price
            tax_totals['total_amount_currency'] = total_price + tax_totals['tax_amount']
            tax_totals['total_amount'] = total_price + tax_totals['tax_amount']

            order.tax_totals = tax_totals

    def action_internal_quotation(self):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not allowed to download internal quotations."))
        return {
            'name': _('Internal Quotation'),
            'type': 'ir.actions.act_window',
            'res_model': 'internal.quotation.wizard',
            'view_mode': 'form',
            'target': 'new',
        }

    def action_customer_quotation(self):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not allowed to download customer quotations."))
        return {
            'name': _('Customer Quotation'),
            'type': 'ir.actions.act_window',
            'res_model': 'customer.quotation.wizard',
            'view_mode': 'form',
            'target': 'new',
        }

    def action_bom_excel_report(self):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not allowed to download BOM reports."))
        return {
            'type': 'ir.actions.act_url',
            'url': f'/wb_crm_quotation_lead/bom_excel_report/{self.id}',
            'target': 'self',
        }