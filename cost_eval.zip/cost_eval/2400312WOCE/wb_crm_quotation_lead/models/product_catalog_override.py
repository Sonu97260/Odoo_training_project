from odoo import models

class ProductCatalogMixinOverride(models.AbstractModel):
    _name = 'product.catalog.mixin'
    _inherit = 'product.catalog.mixin'

    def _get_sections(self, child_field, **kwargs):
        """Return section data including custom wb_section_name field for product catalog.
        Extends the base method to include wb_section_name when available on the child model.
        """
        sections = {}
        no_section_count = 0
        lines = self[child_field]
        
        child_model = self.env[lines._name]
        has_wb_section_name = 'wb_section_name' in child_model._fields
        
        for line in lines.sorted('sequence'):
            if line.display_type == 'line_section':
                section_data = {
                    'id': line.id,
                    'name': line.name,
                    'sequence': line.sequence,
                    'line_count': 0,
                }
                
                if has_wb_section_name and line.wb_section_name:
                    section_data['name'] = line.wb_section_name
                    section_data['wb_section_name'] = line.wb_section_name
                
                sections[line.id] = section_data
                
            elif self._is_line_valid_for_section_line_count(line):
                sec_id = line.get_parent_section_line().id
                if sec_id and sec_id in sections:
                    sections[sec_id]['line_count'] += 1
                else:
                    no_section_count += 1

        if no_section_count > 0 or not sections:
            sections[False] = {
                'id': False,
                'name': self.env._("No Section"),
                'sequence': lines[0].sequence - 1 if lines else 0,
                'line_count': no_section_count,
            }

        return sorted(sections.values(), key=lambda x: x['sequence'])