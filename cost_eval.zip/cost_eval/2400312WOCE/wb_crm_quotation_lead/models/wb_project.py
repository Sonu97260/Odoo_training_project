from odoo import fields, models, api, _
from odoo.exceptions import AccessError


class WBProject(models.Model):
    _name = 'wb.project'
    _description = "Project"

    name = fields.Char(string='Project Name')

    @api.model_create_multi
    def create(self, vals_list):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not allowed to create projects."))
        return super().create(vals_list)

    def write(self, vals):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not allowed to edit projects."))
        return super().write(vals)

    def unlink(self):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not allowed to delete projects."))
        return super().unlink()
