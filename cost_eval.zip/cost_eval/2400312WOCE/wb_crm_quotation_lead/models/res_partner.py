from odoo import fields, models, api, _
from odoo.exceptions import AccessError


class ResPartner(models.Model):
    _inherit = 'res.partner'

    wb_customer_type = fields.Selection([('affiliate', 'Affiliate'), ('direct', 'Direct')], string='Client Type', required=True)
    wb_customer_margin = fields.Char(string='Margin', required=True)

    @api.model_create_multi
    def create(self, vals_list):
        if self.env.user.wb_supervisor or self.env.user.wb_cost_estimator:
            raise AccessError(_("You are not allowed to create clients."))
        for vals in vals_list:
            if vals.get('parent_id') and not vals.get('wb_customer_margin'):
                parent = self.browse(vals['parent_id'])
                if parent.wb_customer_margin:
                    vals['wb_customer_margin'] = parent.wb_customer_margin
        return super().create(vals_list)


    def write(self, vals):
        res = super(ResPartner, self).write(vals)
        if 'wb_customer_margin' in vals: 
            for partner in self: 
                partner.child_ids.write({'wb_customer_margin': 
            vals['wb_customer_margin']}) 
        return res


    def unlink(self):
        if self.env.user.wb_supervisor or self.env.user.wb_cost_estimator:
            raise AccessError(_("You are not allowed to delete clients."))
        return super().unlink()
