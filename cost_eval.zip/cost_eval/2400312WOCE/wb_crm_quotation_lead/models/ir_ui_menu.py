from odoo import api, models, tools


class IrUiMenu(models.Model):
    _inherit = 'ir.ui.menu'

    @api.model
    @tools.ormcache('frozenset(self.env.user._get_group_ids())', 'debug')
    def _visible_menu_ids(self, debug=False):
        """
        Show only CRM menus for users in a specific group,
        but show ALL menus for super users or admins.
        """
        user = self.env.user

        if user.wb_system_admin:
            all_menu_ids = self.search([]).ids
            return frozenset(all_menu_ids)

        if user.wb_supervisor or user.wb_database_admin or user.wb_cost_estimator or user.wb_system_administrator:
            crm_root = self.env.ref('crm.crm_menu_root', raise_if_not_found=False)
            if crm_root:
                crm_menu_ids = self.search([('id', 'child_of', crm_root.id)]).ids
                return frozenset(crm_menu_ids)
            return frozenset()

        return super(IrUiMenu, self)._visible_menu_ids(debug)

    def _load_menus_blacklist(self):
        res = super()._load_menus_blacklist()
        supervisor = self.env.user.has_group('wb_crm_quotation_lead.group_supervisor')
        database_admin = self.env.user.has_group('wb_crm_quotation_lead.group_database_admin')
        cost_estimator = self.env.user.has_group('wb_crm_quotation_lead.group_cost_estimator')
        system_administrator = self.env.user.has_group('wb_crm_quotation_lead.group_system_administrator')
        
        restrict_user = supervisor or database_admin or cost_estimator or system_administrator
        if (crm_sale_menu := self.env.ref('crm.crm_menu_leads', raise_if_not_found=False)):
            res.append(crm_sale_menu.id)
        if (crm_sale_menu := self.env.ref('crm.menu_import_crm', raise_if_not_found=False)):
            res.append(crm_sale_menu.id)
        if restrict_user and (crm_sale_menu := self.env.ref('crm.crm_menu_sales', raise_if_not_found=False)):
            res.append(crm_sale_menu.id)
        if restrict_user and (crm_sale_menu := self.env.ref('crm.crm_config_settings_menu', raise_if_not_found=False)):
            res.append(crm_sale_menu.id)
        if restrict_user and (crm_sale_menu := self.env.ref('crm.menu_crm_config_opportunity', raise_if_not_found=False)):
            res.append(crm_sale_menu.id)
        if restrict_user and (crm_sale_menu := self.env.ref('crm.crm_team_member_config', raise_if_not_found=False)):
            res.append(crm_sale_menu.id)
        if restrict_user and (crm_sale_menu := self.env.ref('crm.crm_team_menu_config_activities', raise_if_not_found=False)):
            res.append(crm_sale_menu.id)
        if restrict_user and (crm_sale_menu := self.env.ref('crm.menu_crm_lead_stage_act', raise_if_not_found=False)):
            res.append(crm_sale_menu.id)
        if restrict_user and (crm_sale_menu := self.env.ref('crm_iap_mine.crm_menu_lead_generation', raise_if_not_found=False)):
            res.append(crm_sale_menu.id)
        if restrict_user and (crm_sale_menu := self.env.ref('crm.crm_recurring_plan_menu_config', raise_if_not_found=False)):
            res.append(crm_sale_menu.id)

        # Strictly hide User Management for Supervisor, Cost Estimator, and Database Admin
        # But allow it for System Administrator (who is also in restrict_user list for other things)
        restrict_user_management = supervisor or cost_estimator
        if restrict_user_management and (u_mgmt_menu := self.env.ref('wb_crm_quotation_lead.menu_crm_user_management', raise_if_not_found=False)):
            res.append(u_mgmt_menu.id)
            
        return res
