from odoo import fields, models, api, _
from odoo.exceptions import AccessError
from datetime import datetime


class CrmLead(models.Model):
    _inherit = 'crm.lead'
    _description = "Lead"

    wb_lead_number = fields.Char(string='Lead Number', readonly=True, copy=False)
    wb_project_id = fields.Many2one('wb.project', string='Project')
    wb_is_allow_edit = fields.Boolean(string="Allow Edit", default=True)
    wb_ro_counter = fields.Integer(string='RO Counter', default=0)
    wb_is_hide_quotation_button = fields.Boolean('Hide Quotation Button?', related='stage_id.wb_is_hide_quotation_button', store=True)
    is_stage_lead3 = fields.Boolean(
        compute="_compute_stage_lead3",
    )
    wb_can_create_partner = fields.Boolean(compute='_compute_wb_can_create_partner')

    def _compute_wb_can_create_partner(self):
        user = self.env.user
        # Restricted groups: Supervisor and Cost Estimator
        is_restricted = (
            user.has_group('wb_crm_quotation_lead.group_supervisor') or
            user.has_group('wb_crm_quotation_lead.group_cost_estimator')
        )
        for rec in self:
            rec.wb_can_create_partner = not is_restricted

    wb_can_create_project = fields.Boolean(compute='_compute_wb_can_create_project')

    def _compute_wb_can_create_project(self):
        user = self.env.user
        # Restricted groups: Database Admin
        is_restricted = user.has_group('wb_crm_quotation_lead.group_database_admin')
        for rec in self:
            rec.wb_can_create_project = not is_restricted

    def write(self, vals):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not allowed to edit leads."))
        
        if self.env.user.wb_cost_estimator:
            if 'active' in vals:
                if vals['active']:
                    raise AccessError(_("You are not allowed to restore leads."))
                else:
                    raise AccessError(_("You are not allowed to archive or mark leads as lost."))
            if 'lost_reason_id' in vals:
                raise AccessError(_("You are not allowed to mark leads as lost."))

        res = super(CrmLead, self).write(vals)

        if 'partner_id' in vals or 'wb_project_id' in vals:
            for lead in self:
                if lead.wb_is_allow_edit:
                    sync_vals = {}
                    if 'partner_id' in vals:
                        sync_vals['partner_id'] = vals['partner_id']
                    if 'wb_project_id' in vals:
                        sync_vals['wb_project_id'] = vals['wb_project_id']
                    
                    if sync_vals:
                        editable_quotations = self.env['sale.order'].search([
                            ('opportunity_id', '=', lead.id),
                            ('wb_is_allow_edit', '=', True)
                        ])
                        if editable_quotations:
                            editable_quotations.write(sync_vals)
        return res

    def action_open_duplicate_lead_wizard(self):
        self.ensure_one()

        quotation_ids = self.env['sale.order'].search([
            ('opportunity_id', '=', self.id)
        ])

        return {
            'name': 'Duplicate Lead',
            'type': 'ir.actions.act_window',
            'res_model': 'crm.lead.duplicate.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_lead_id': self.id,
                'default_quotation_ids': quotation_ids.ids,
                'default_partner_id': self.partner_id.id,
                'default_wb_project_id': self.wb_project_id.id,
            }
        }

    @api.depends('stage_id')
    def _compute_stage_lead3(self):
        stage3 = self.env.ref('crm.stage_lead3', raise_if_not_found=False)
        for rec in self:
            rec.is_stage_lead3 = (rec.stage_id.id == (stage3.id if stage3 else 0))

    @api.model_create_multi
    def create(self, vals_list):
        if self.env.user.wb_database_admin:
            raise AccessError(_("You are not allowed to create leads."))
        today = fields.Date.context_today(self)
        year_str = today.strftime('%y')
        month_str = today.strftime('%m')

        last_lead = self.env['crm.lead'].search([('wb_lead_number', '!=', False)],order='id desc',limit=1)

        if last_lead and last_lead.wb_lead_number:
            last_year = last_lead.create_date.strftime('%y')
            last_seq = int(last_lead.wb_lead_number)
        else:
            last_year = year_str
            last_seq = 0

        counter = 0 if last_year != year_str else last_seq

        for vals in vals_list:
            counter += 1
            seq_num = str(counter).zfill(4)

            user_id = vals.get('user_id') or self.env.user.id
            user = self.env['res.users'].browse(user_id)
            abbreviation = user.wb_abbreviation_name.upper() if user.wb_abbreviation_name else ""

            vals['wb_lead_number'] = seq_num

            if abbreviation:
                vals['name'] = f"CE{year_str}{month_str}-{seq_num}-{abbreviation}"
            else:
                vals['name'] = f"CE{year_str}{month_str}-{seq_num}"

        return super().create(vals_list)

    def _prepare_opportunity_quotation_context(self):
        quotation_context = super()._prepare_opportunity_quotation_context()
        quotation_context['default_wb_project_id'] = self.wb_project_id.id
        quotation_context['default_stage_id'] = self.stage_id.id
        quotation_context['default_wb_is_allow_edit'] = self.wb_is_allow_edit
        return quotation_context

    def unlink(self):
        if self.env.user.wb_database_admin or self.env.user.wb_cost_estimator:
            raise AccessError(_("You are not allowed to delete leads."))
        return super().unlink()

    def _prepare_opportunity_quotation_context(self):
        quotation_context = super()._prepare_opportunity_quotation_context()
        quotation_context['default_wb_project_id'] = self.wb_project_id.id
        quotation_context['default_stage_id'] = self.stage_id.id
        quotation_context['default_wb_is_allow_edit'] = self.wb_is_allow_edit
        return quotation_context