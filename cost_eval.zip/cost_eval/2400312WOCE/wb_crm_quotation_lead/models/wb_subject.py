from odoo import fields, models


class WBSubject(models.Model):
    _name = 'wb.subject'
    _description = "Subject"

    name = fields.Char(string='Subject')
