from odoo import models, fields

class WbValidity(models.Model):
    _name = "wb.validity"
    _description = "Validity"
    _rec_name = 'validity'

    validity = fields.Char("Validity")
