from odoo import api, fields, models


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    wb_section_sequence = fields.Integer(string="Item", default=0, copy=False, index=True)
    wb_section_qty = fields.Float(string="Qty", digits='Product Unit', default=1.0)
    wb_section_name = fields.Char(string="Name")
    wb_is_customer_supply = fields.Boolean("Customer Supply?")
    wb_is_show_to_client = fields.Boolean("Hide to Client?")
    wb_product_description = fields.Text(string="Description", compute='_compute_wb_product_description', store=True, readonly=False)
    wb_sub_nsp_price = fields.Float(string="Sub-NSP", compute='_compute_wb_sub_nsp_price', digits='Product Price', store=True)
    wb_sub_nsp_pb_price = fields.Float(string="Sub-NSP(PB)", digits='Product Price', readonly=False, store=True)
    wb_sub_nsp_pb_margin_price = fields.Float(string="Margin", digits='Product Price', store=True)
    wb_section_price_unit = fields.Float(string="Unit Price", digits='Product Price', store=True, compute='_compute_wb_section_price_unit')
    wb_total_sub_nsp_price = fields.Float(string="Sub-NSP", compute='_compute_wb_total_sub_nsp_price', digits='Product Price', store=True)
    wb_customer_margin = fields.Char(string='Customer Margin', related='order_id.partner_id.wb_customer_margin')
    user_has_discount_permission = fields.Boolean(
        string="User Can See Discount",
        compute="_compute_user_discount_access"
    )

    def _compute_user_discount_access(self):
        for line in self:
            line.user_has_discount_permission = self.env.user.allow_discount

    @api.depends('product_id', 'name')
    def _compute_wb_product_description(self):
        for line in self:
            if line.name:
                line.wb_product_description = line.product_id.description_sale
            else:
                line.wb_product_description = line._get_sale_order_line_multiline_description_sale() if line.product_id else ''

    @api.depends('price_unit', 'product_uom_qty')
    def _compute_wb_sub_nsp_price(self):
        for line in self:
            if line.price_unit and line.product_uom_qty and line.price_unit > 0:
                line.wb_sub_nsp_price = line.price_unit * line.product_uom_qty
            else:
                line.wb_sub_nsp_price = 0.0

    @api.depends('wb_section_price_unit', 'wb_section_qty')
    def _compute_wb_total_sub_nsp_price(self):
        for line in self:
            if line.wb_section_price_unit and line.wb_section_qty:
                line.wb_total_sub_nsp_price = line.wb_section_price_unit * line.wb_section_qty
            else:
                line.wb_total_sub_nsp_price = 0.0

    @api.depends('order_id.order_line.wb_sub_nsp_price', 'order_id.order_line.display_type', 'order_id.order_line.sequence')
    def _compute_wb_section_price_unit(self):
        # Optimize by iterating per order
        for order in self.mapped('order_id'):
            current_section = False
            section_sum = 0.0
            # Collect sums for each section
            section_sums = {}
            for line in order.order_line:
                if line.display_type == 'line_section':
                    current_section = line
                    section_sums[line.id] = 0.0
                elif not line.display_type and current_section:
                    # Only add positive values (exclude discounts)
                    if line.wb_sub_nsp_price > 0:
                        section_sums[current_section.id] += line.wb_sub_nsp_price
            # Assign computed values
            for line in order.order_line:
                if line.display_type == 'line_section':
                    line.wb_section_price_unit = section_sums.get(line.id, 0.0)
                # Keep existing value for non-sections or initialize if needed (though compute field usually recomputes all)
                # For non-section lines, this field is not used/visible typically, but good to handle.
                elif not line.wb_section_price_unit:
                     line.wb_section_price_unit = 0.0

    @api.depends('product_id', 'product_uom_qty', 'product_uom_id', 'wb_is_customer_supply')
    def _compute_price_unit(self):
        for line in self:
            if not line.product_id:
                line.price_unit = 0.0
            elif line.wb_is_customer_supply:
                line.price_unit = 0.0
            else:
                price = line.with_company(line.company_id)._get_pricelist_price()
                line.price_unit = line.product_id._get_tax_included_unit_price(
                    line.company_id or line.env.company,
                    line.currency_id or line.order_id.currency_id,
                    line.order_id.date_order or fields.Date.today(),
                    'sale',
                    product_price_unit=price,
                    product_currency=line.currency_id
                )

    def _next_section_sequence(self, order):
        """Return next sequence number for section lines in given order."""
        last = self.search(
            [
                ("order_id", "=", order.id),
                ("display_type", "=", "line_section"),
            ],
            order="wb_section_sequence desc",
            limit=1,
        )
        return (last.wb_section_sequence or 0) + 1

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        for record in records:

            if record.display_type == "line_section":
                if not record.wb_section_sequence:
                    seq = record._next_section_sequence(record.order_id)
                    record.wb_section_sequence = seq

            else:
                if record.wb_section_sequence:
                    record.wb_section_sequence = 0

        return records

    def write(self, vals):
        res = super().write(vals)

        for line in self:

            if line.display_type == "line_section" and not line.wb_section_sequence:
                line.wb_section_sequence = line._next_section_sequence(line.order_id)

            if line.display_type != "line_section" and line.wb_section_sequence:
                line.wb_section_sequence = 0

        return res


    def get_section_sub_nsp_pb_total(self):
        self.ensure_one()
        # Only for section lines
        if self.display_type != 'line_section':
            return 0.0
        # If the section line has a stored value, use it (matches backend view)
        if self.wb_sub_nsp_pb_price:
            return self.wb_sub_nsp_pb_price
        total = 0.0
        current_section_found = False
        for line in self.order_id.order_line:
            if line.id == self.id:
                current_section_found = True
                continue
            if current_section_found:
                if line.display_type == 'line_section':
                    break # Next section reached
                if not line.display_type: # Product line
                    total += line.wb_sub_nsp_price
        return total
