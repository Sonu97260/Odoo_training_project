from odoo import models, api , fields


class ProductTemplate(models.Model):
    _inherit = 'product.template'
    _rec_names_search = ['description_sale']

    @api.model
    def default_get(self, fields):
        res = super(ProductTemplate, self).default_get(fields)
        if 'type' in fields and not self.env.context.get('default_type'):
            res['type'] = 'service'
        return res

    custom_product_type = fields.Selection([
        ('service', 'Service')
    ], string='Product Type', default='service', required=True)
