from odoo import models, fields

class SpreadsheetDashboardGroup(models.Model):
    _inherit = 'spreadsheet.dashboard.group'

    active = fields.Boolean(default=True)
