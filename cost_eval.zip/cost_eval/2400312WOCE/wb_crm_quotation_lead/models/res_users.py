from odoo import fields, models, api


class ResUsers(models.Model):
    _inherit = 'res.users'

    wb_manager_ids = fields.Many2many("res.users", "user_manager_rel", "user_id", "manager_id", string="Manager")
    wb_abbreviation_name = fields.Char(string='Abbreviation')
    wb_system_admin = fields.Boolean(string='Super Admin')
    wb_database_admin = fields.Boolean(string='Database Admin')
    wb_cost_estimator = fields.Boolean(string='Cost Estimator')
    wb_system_administrator = fields.Boolean(string='System Admin')
    wb_supervisor = fields.Boolean(string='Supervisor')
    wb_is_superuser = fields.Boolean("Super User?")
    allow_discount = fields.Boolean(string="Allow Discount")
    cus_designation = fields.Char(string='Designation')

    @api.onchange('wb_system_admin')
    def _onchange_system_admin(self):
        if self.wb_system_admin:
            self.wb_supervisor = False

    @api.onchange('wb_supervisor')
    def _onchange_supervisor(self):
        if self.wb_supervisor:
            self.wb_system_admin = False

    def _update_user_groups(self):
        group_mapping = {
            'wb_system_admin': 'wb_crm_quotation_lead.group_system_admin',
            'wb_supervisor': 'wb_crm_quotation_lead.group_supervisor',
            'wb_database_admin': 'wb_crm_quotation_lead.group_database_admin',
            'wb_cost_estimator': 'wb_crm_quotation_lead.group_cost_estimator',
            'wb_system_administrator': 'wb_crm_quotation_lead.group_system_administrator',
        }
        for record in self:
            if not record.id:
                continue  # Skip unsaved records
            for field, group_xml_id in group_mapping.items():
                group = self.env.ref(group_xml_id, raise_if_not_found=False)
                if not group:
                    continue

                if record[field]:
                    if record not in group.user_ids:
                        group.sudo().write({'user_ids': [(4, record.id)]})
                else:
                    if record in group.user_ids:
                        group.sudo().write({'user_ids': [(3, record.id)]})
            sale_manager_group = self.env.ref("sales_team.group_sale_manager")
            if sale_manager_group:
                if record.wb_supervisor or record.wb_database_admin or record.wb_cost_estimator or record.wb_system_administrator:
                    if record not in sale_manager_group.user_ids:
                        sale_manager_group.sudo().write({'user_ids': [(4, record.id)]})

    @api.onchange('wb_system_admin', 'wb_supervisor', 'wb_database_admin', 'wb_cost_estimator', 'wb_system_administrator')
    def _onchange_update_user_groups(self):
        self._update_user_groups()

    @api.model_create_multi
    def create(self, vals):
        record = super(ResUsers, self).create(vals)
        record._update_user_groups()
        return record

    def write(self, vals):
        res = super(ResUsers, self).write(vals)
        self._update_user_groups()
        return res

    def _update_user_groups(self):
        group_mapping = {
            'wb_system_admin': 'wb_crm_quotation_lead.group_system_admin',
            'wb_supervisor': 'wb_crm_quotation_lead.group_supervisor',
            'wb_database_admin': 'wb_crm_quotation_lead.group_database_admin',
            'wb_cost_estimator': 'wb_crm_quotation_lead.group_cost_estimator',
            'wb_system_administrator': 'wb_crm_quotation_lead.group_system_administrator',
        }
        for record in self:
            if not record.id:
                continue  # Skip unsaved records
            for field, group_xml_id in group_mapping.items():
                group = self.env.ref(group_xml_id, raise_if_not_found=False)
                if not group:
                    continue

                if record[field]:
                    if record not in group.user_ids:
                        group.sudo().write({'user_ids': [(4, record.id)]})
                else:
                    if record in group.user_ids:
                        group.sudo().write({'user_ids': [(3, record.id)]})

            # --- START OF FIX ---
            sale_manager_group = self.env.ref("sales_team.group_sale_manager")
            sale_all_leads_group = self.env.ref("sales_team.group_sale_salesman_all_leads")

            # Supervisor, Database Admin, System Admin -> Sales Manager (Full Access)
            if sale_manager_group:
                if record.wb_supervisor or record.wb_database_admin or record.wb_system_administrator:
                    if record not in sale_manager_group.user_ids:
                        sale_manager_group.sudo().write({'user_ids': [(4, record.id)]})

            # Cost Estimator -> Salesman All Leads (Restricted Access)
            if sale_all_leads_group:
                if record.wb_cost_estimator:
                    # Remove from Manager group if they are currently in it (downgrade rights)
                    if sale_manager_group and record in sale_manager_group.user_ids and not (
                            record.wb_supervisor or record.wb_database_admin or record.wb_system_administrator):
                        sale_manager_group.sudo().write({'user_ids': [(3, record.id)]})

                    # Add to Salesman group
                    if record not in sale_all_leads_group.user_ids:
                        sale_all_leads_group.sudo().write({'user_ids': [(4, record.id)]})