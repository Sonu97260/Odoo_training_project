from odoo import models, fields

class WbNotes(models.Model):
    _name = "wb.notes"
    _description = "Notes"
    _rec_name = 'note'

    note = fields.Char(string="Note", required=True)
