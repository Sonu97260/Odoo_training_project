from lxml import etree
from odoo import models, api, _
from odoo.exceptions import AccessError


class AccountPaymentTerm(models.Model):
    _inherit = "account.payment.term"

    def _block_database_admin(self):
        if (
            self.env.user.has_group("wb_crm_quotation_lead.group_database_admin")
            and not self.env.context.get("allow_payment_term_sudo")
        ):
            raise AccessError(_("Database Admin is not allowed to manage Payment Terms."))

    @api.model
    def get_view(self, view_id=None, view_type='form', **options):
        res = super().get_view(view_id, view_type, **options)
        if view_type == 'list' and self.env.user.has_group('wb_crm_quotation_lead.group_database_admin'):
            doc = etree.XML(res['arch'])
            doc.set('create', 'false')
            doc.set('delete', 'false')
            res['arch'] = etree.tostring(doc, encoding='unicode')
        return res

    @api.model
    def create(self, vals):
        self._block_database_admin()
        return super().create(vals)

    def write(self, vals):
        self._block_database_admin()
        return super().write(vals)

    def unlink(self):
        self._block_database_admin()
        return super().unlink()
