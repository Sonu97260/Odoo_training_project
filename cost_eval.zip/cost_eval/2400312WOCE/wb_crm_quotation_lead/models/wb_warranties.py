from odoo import fields, models


class WBWarranties(models.Model):
    _name = 'wb.warranties'
    _description = "Warranties"

    name = fields.Char(string='Warranties')
