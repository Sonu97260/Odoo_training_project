from odoo import api, models


class Digest(models.Model):
    _inherit = "digest.digest"

    @api.model
    def _get_system_debrand_name(self):
        digest_record = self.env.ref('digest.digest_digest_default', raise_if_not_found=False)
        if digest_record:
            digest_record.write({'name': 'Your ERP Periodic Digest'})
