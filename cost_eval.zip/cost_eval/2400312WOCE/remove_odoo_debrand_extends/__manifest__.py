{
    'name': 'Remove Odoo De-brand Extends',
    'version': '19.0.0.1',
    'category': 'Website',
    'summary': 'Removes Odoo Brands or links from the login page and settings',
    'author': 'Wan Buffer',
    'license': 'AGPL-3',
    'depends': ['base', 'digest', 'link_tracker'],
    'data': [
        'data/digest_data.xml',
        'data/remove_odoo_bot.xml',
        'views/remove_login_links.xml',
        'views/res_config_settings_views.xml',
    ],
    'installable': True,
    'application': False,
}
