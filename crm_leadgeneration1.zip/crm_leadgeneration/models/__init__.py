from . import crm_lead
from . import res_setting
# from . import wizard_pop